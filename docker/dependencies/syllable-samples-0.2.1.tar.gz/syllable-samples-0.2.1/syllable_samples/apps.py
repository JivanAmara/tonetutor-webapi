from django.apps import AppConfig


class SyllableSamplesConfig(AppConfig):
    name = 'syllable_samples'
